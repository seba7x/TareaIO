package mhapp;

import java.util.ArrayList;
import java.util.List;

/**
*
* @author Admin
*/
public class Grafo {
    private List<Star> stars;
    private List<Edge> edges;

    public Grafo() {
        this.stars = null;
        this.edges = null;
    }
    
    public void addStar(Star star){
        if(stars == null){
            stars = new ArrayList<>();
        }
        stars.add(star);   
    }
    public List<Star> getStars(){
        return stars;
    }
    
    @Override
    public String toString() {
        return "Graph [stars=" + stars + "]";
    }

    public Star getStar(int i){
        return this.stars.get(i);
    }
    
    /**
     *
     * @param edge
     */
    public void addEdge(Edge edge){
        if(edges == null)
            edges = new ArrayList<>();
        edges.add(edge);
       
    }
    public boolean delStar(Star s){
       return stars.remove(s);
    }
    
    public List<Edge> getEdges(){
        return edges;
    }
    
    public Edge getEdge(int i){
        
        return this.edges.get(i);
    }
    public boolean delEdge(Edge edge){
        return this.edges.remove(edge);
    }
    
    public boolean edgeExist(int n){
       for(int i=0; i<edges.size();i++){
           if(edges.get(i).getDestination().getId() == edges.get(n).getDestination().getId())
               return true;
       }
       return false;
    }
}