/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mhapp;

import java.util.Random;

/**
 *
 * @author Admin
 */
public class MHapp {
    private static Grafo space;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        space = new Grafo();
// se inicializa la poblacion de estrellas 
        inicializarPoblacion(space);
// se elige la mejor estrella como black hole
        int contador = 0;
        
        do{
    
            Star currentStar;
            Star prevStar;
            int blackHoleID=0;
            
            Star bestStar = new Star();
            
            for(int i=0;i<space.getStars().size();i++){
                currentStar = space.getStar(i);
                if(currentStar.getFitness()>bestStar.getFitness()){
                    bestStar = currentStar;
                }
            }
            System.out.println("LA MEJOR STAR ES : " + bestStar.getId() );
            
            for(int i=0; i<space.getStars().size() ; i++){
                currentStar = space.getStar(i);
                if(currentStar.getId() == bestStar.getId()){
                    currentStar.setBH(true);
                    blackHoleID = currentStar.getId();
                }
            }

            int idToFalse = bestStar.getId();
            
            for(int i=0; i<space.getStars().size(); i++){
                currentStar = space.getStar(i);
                if(currentStar.getId()!=idToFalse){
                    currentStar.setBH(false);              
                }
            }
            
            
            
            mostrarPoblacion(space);
            
            crearCaminos(space,blackHoleID);
            
            mostrarCaminos(space);
            System.out.println("\n");
            
            float rad = crearRadioBH(space);
            System.out.println("\n");

            movimientoAbsorvente(space,rad);
            System.out.println("\n"); 
/*


    //Movimiento de absorcion

            for(int i=0 ; i<space.getEdges().size() ; i++){

                Edge e = space.getEdge(i);

                //System.out.println("Edge of star : " + e.getOrigin().getId() + " to " + e.getDestination().getId()+"\nDist : "+ e.getDistance() );

                float distFinal, distInicial;
                Random random = new Random();
                float rand =  random.nextFloat()*-1;

                distInicial = e.getDistance();
                distFinal = distInicial + rand * distInicial;
                //System.out.println("I: "+distInicial+" F: "+ distFinal);
                e.setDistance(distFinal);

                if(rad > e.getDistance()){
                    if(space.delStar(e.getOrigin())){
                        if(space.delEdge(e)){
                            random = new Random();
                            rand = random.nextFloat();

                            Star newStar = new Star();
                            newStar.setValue(rand);
                            newStar.setFitness(rand);
                            newStar.setId(i);
                            space.addStar(newStar);

                            e.setOrigin(newStar);
                            e.setDestination(space.getStar(blackHole.getId()));
                            e.setDistance(rand * 1000);
                            space.addEdge(e);
                        }
                    }
                }

            }
            
            
            contador++;
            System.out.println("--------------------------------------------------");*/
        }while(contador<10);
        
        for (int i=0; i<space.getStars().size(); i++){
            Star s = space.getStar(i);
            System.out.println("is blackHole : "+s.isBH());
        }

    }

    private static void crearCaminos(Grafo space, int BlackHoleID) {
            Star currentStar ;
            Star blackHole = space.getStar(BlackHoleID);
            
            System.out.println("\n");
            for(int i=0; i<space.getStars().size(); i++){
               Random random = new Random();
               float rand =  random.nextFloat();
               
               currentStar = space.getStar(i);
                
               if(!currentStar.isBH()){
                   Edge e= new Edge();
                   e.setOrigin(currentStar);
                   e.setDestination(blackHole);
                   e.setDistance(rand*1000);
                   
                   space.addEdge(e);
               }
               
            }             
    }

    private static void inicializarPoblacion(Grafo space) {
        for(int i=0 ; i<10 ; i++){
            Random random = new Random();
            float rand =  random.nextFloat();
         
            Star s = new Star();
            s.setValue(rand);
            s.setFitness(rand);
            s.setId(i);
    
            space.addStar(s);
            
            //System.out.println("STAR : " + s.getId());
            //System.out.println("Fitness : " + s.getFitness()+"\n____________________________________________________________\n"); 
        }
        System.out.println("____________________________________________________________\n");
    }
    
    private static void mostrarPoblacion(Grafo space){
        Star s;
        for(int i=0; i<space.getStars().size();i++){
            s = space.getStar(i);
            
            System.out.println("STAR : " + s.getId());
            System.out.println("Fitness : " + s.getFitness());
            if(s.isBH()) System.out.println("es BH\n");
        }
    }
    private static void mostrarCaminos(Grafo space){
        for(int i=0; i<space.getEdges().size(); i++){
                Edge e;
                e = space.getEdge(i);
                System.out.println("Camino : "+ e.getOrigin().getId()+" to "+e.getDestination().getId() + " cost : "+e.getDistance());
            }
    }
    private static float crearRadioBH(Grafo space){
            float rad=0;
            float sum=0;
            Star blackHole = getBlackhole(space);
            Star currentStar;
            for(int i=0; i<space.getStars().size(); i++){
                currentStar = space.getStar(i);
                if(!currentStar.isBH())
                    sum+= currentStar.getFitness();
            }
            return rad = blackHole.getFitness() / sum;
            
    }
    private static Star getBlackhole(Grafo space){
        for(int i=0; i<space.getStars().size(); i++){
            Star s = space.getStar(i);
            if(s.isBH())
                return s;                 
        }
        return null;
    }
    
    private static void movimientoAbsorvente(Grafo space,float rad){
        for(int i=0 ; i<space.getEdges().size() ; i++){
            System.out.println("Iteracion #"+i);
            Edge camino = space.getEdge(i);
            float distFinal, distInicial;
            Random random = new Random();
            float rand =  random.nextFloat()*-1;
            distInicial = camino.getDistance();
            distFinal = distInicial + rand * distInicial;
            //System.out.println("I: "+distInicial+" F: "+ distFinal);
            camino.setDistance(distFinal);
            rad=400;
            if(eliminarSiCruza(space,rad,camino)){
                System.out.println("SE ELIMINÓ una estrella ");
            }
              
        }
        
        
    }
    private static boolean eliminarSiCruza(Grafo space, float rad,Edge e){
        int idToEliminate;
        if(rad > e.getDistance()){
            idToEliminate = e.getOrigin().getId();
                    if(space.delStar(e.getOrigin())){
                        if(space.delEdge(e)){
                            Random random = new Random();
                            float rand = random.nextFloat();

                            Star newStar = new Star();
                            newStar.setValue(rand);
                            newStar.setFitness(rand);
                            newStar.setId(idToEliminate);
                            space.addStar(newStar);

                            e.setOrigin(newStar);
                            Star destino = getBlackhole(space);
                            e.setDestination(destino);
                            e.setDistance(rand * 1000);
                            space.addEdge(e);
                            return true;
                        }
                    }
                }
        return false;
    }
}
        
        
        
        
        
        
 
    
  

