/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mhapp;

/**
 *
 * @author Admin
 */
public class Edge {
    private Star origin;
    private Star destination;
    private float distance;
 
    public Edge(Star origin, Star destination, int distance) {
        this.origin = origin;
        this.destination = destination;
        this.distance = distance;
    }

    Edge() {
        this.origin = null;
        this.destination = null;
        this.distance = 0;
    }
 
    public Star getOrigin() {
        return origin;
    }
 
    public void setOrigin(Star origin) {
        this.origin = origin;
    }
 
    public Star getDestination() {
        return destination;
    }
 
    public void setDestination(Star destination) {
        this.destination = destination;
    }
 
    public float getDistance() {
        return distance;
    }
 
    public void setDistance(float distance) {
        this.distance = distance;
    }
 
 
}