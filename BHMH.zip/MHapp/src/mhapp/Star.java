/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mhapp;



/**
 *
 * @author Admin
 */
public class Star {
    private int id;
    private float fitness;
    private float value;
    private boolean BH;
    
    public Star() {
        this.BH = false;
        this.fitness = 0;
        this.value = 0;
       
    }


    
    
 
    

    public float getFitness() {
        return fitness;
    }

    public void setFitness(float fitness) {
        this.fitness = fitness;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public boolean isBH() {
        return BH;
    }

    public void setBH(boolean isBH) {
        this.BH = isBH;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
}
